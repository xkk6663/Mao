"""Companion configuration; dependencies are explicitly injected."""
from __future__ import annotations

from typing import Any, Callable
from pathlib import Path
import json


class ConfigurationService:
    """Domain implementation; constructor callbacks preserve facade test seams."""

    def __init__(self, *,
                 dep_DEFAULT_CONFIG: Callable[..., Any],
                 dep_LIVE2D_EXPRESSION_SLOT_IDS: Callable[..., Any],
                 dep_LIVE2D_MOTION_SLOT_IDS: Callable[..., Any],
                 dep__live2d_model_ids: Callable[..., Any],
                 dep_settings: Callable[..., Any],
                 ) -> None:
        self._dep_DEFAULT_CONFIG = dep_DEFAULT_CONFIG
        self._dep_LIVE2D_EXPRESSION_SLOT_IDS = dep_LIVE2D_EXPRESSION_SLOT_IDS
        self._dep_LIVE2D_MOTION_SLOT_IDS = dep_LIVE2D_MOTION_SLOT_IDS
        self._dep__live2d_model_ids = dep__live2d_model_ids
        self._dep_settings = dep_settings

    def _migrate_config(self, data: dict[str, Any]) -> dict[str, Any]:
        migrated = dict(data)
        try:
            schema_version = int(migrated.get("config_schema_version") or 1)
        except (TypeError, ValueError):
            schema_version = 1
        if schema_version < 2:
            try:
                legacy_screen_timeout = int(migrated.get("screen_request_timeout_seconds", 12))
            except (TypeError, ValueError):
                legacy_screen_timeout = 12
            if legacy_screen_timeout == 12:
                migrated["screen_request_timeout_seconds"] = 25
        migrated["config_schema_version"] = 2
        return migrated

    def _normalize_live2d_motion_slots(self, value: object) -> dict[str, dict[str, str]]:
        if not isinstance(value, dict):
            return {}
        normalized: dict[str, dict[str, str]] = {}
        for raw_model_id, raw_slots in list(value.items())[:30]:
            model_id = str(raw_model_id or "").strip()[:100]
            if not model_id or not isinstance(raw_slots, dict):
                continue
            slots: dict[str, str] = {}
            for raw_slot, raw_group in raw_slots.items():
                slot = str(raw_slot or "").strip().lower()
                group = str(raw_group or "").strip()[:120]
                if slot in self._dep_LIVE2D_MOTION_SLOT_IDS() and group:
                    slots[slot] = group
            if slots:
                normalized[model_id] = slots
        return normalized

    def _normalize_live2d_expression_slots(self, value: object) -> dict[str, dict[str, str]]:
        if not isinstance(value, dict):
            return {}
        normalized: dict[str, dict[str, str]] = {}
        for raw_model_id, raw_slots in list(value.items())[:30]:
            model_id = str(raw_model_id or "").strip()[:100]
            if not model_id or not isinstance(raw_slots, dict):
                continue
            slots: dict[str, str] = {}
            for raw_slot, raw_expression in raw_slots.items():
                slot = str(raw_slot or "").strip().lower()
                expression = str(raw_expression or "").strip()[:120]
                if slot in self._dep_LIVE2D_EXPRESSION_SLOT_IDS() and expression:
                    slots[slot] = expression
            if slots:
                normalized[model_id] = slots
        return normalized

    def load_config(self) -> dict[str, Any]:
        data = dict(self._dep_DEFAULT_CONFIG())
        try:
            saved = json.loads(self._dep_settings().companion_config_path.read_text(encoding="utf-8"))
            if isinstance(saved, dict):
                data.update(self._migrate_config(saved))
        except (OSError, ValueError, json.JSONDecodeError):
            pass
        data["voice_enabled"] = bool(data.get("voice_enabled", True))
        data["voice_volume"] = max(0, min(100, int(data.get("voice_volume", 85))))
        data["voice_streaming_enabled"] = bool(data.get("voice_streaming_enabled", True))
        pet_speech_language = str(data.get("pet_speech_language") or "zh").strip().lower()
        data["pet_speech_language"] = pet_speech_language if pet_speech_language in {"zh", "ja"} else "zh"
        data["speak_screen_observations"] = bool(data.get("speak_screen_observations", True))
        data["speak_game_observations"] = bool(data.get("speak_game_observations", True))
        data["screen_ai_enabled"] = bool(data.get("screen_ai_enabled", True))
        data["screen_audio_enabled"] = bool(data.get("screen_audio_enabled", True))
        screen_audio_model = str(data.get("screen_audio_model") or "base").strip().lower()
        data["screen_audio_model"] = screen_audio_model if screen_audio_model in {"tiny", "base", "small"} else "base"
        screen_audio_language = str(data.get("screen_audio_language") or "auto").strip().lower()
        data["screen_audio_language"] = screen_audio_language if screen_audio_language in {"auto", "zh", "ja", "en"} else "auto"
        data["screen_audio_chunk_seconds"] = max(4, min(15, int(data.get("screen_audio_chunk_seconds", 5))))
        screen_vision_route = str(data.get("screen_vision_route") or "local").strip().lower()
        data["screen_vision_route"] = screen_vision_route if screen_vision_route in {"local", "cloud"} else "local"
        data["screen_vision_model_id"] = (
            str(data.get("screen_vision_model_id") or "auto-fast").strip()[:200] or "auto-fast"
        )
        data["screen_direct_voice_enabled"] = bool(data.get("screen_direct_voice_enabled", True))
        data["screen_change_threshold"] = max(1.0, min(50.0, float(data.get("screen_change_threshold", 4.0))))
        data["screen_analysis_interval_seconds"] = max(5, min(600, int(data.get("screen_analysis_interval_seconds", 5))))
        data["screen_request_timeout_seconds"] = max(5, min(60, int(data.get("screen_request_timeout_seconds", 25))))
        data["screen_voice_cooldown_seconds"] = max(5, min(600, int(data.get("screen_voice_cooldown_seconds", 5))))
        data["screen_minimum_importance"] = max(0.1, min(1.0, float(data.get("screen_minimum_importance", 0.62))))
        data["screen_daily_cost_limit_yuan"] = max(0.1, min(1000.0, float(data.get("screen_daily_cost_limit_yuan", 5.0))))
        call_asr_engine = str(data.get("pet_call_asr_engine") or "auto").strip().lower()
        data["pet_call_asr_engine"] = (
            call_asr_engine if call_asr_engine in {"auto", "whisper", "sensevoice", "paraformer"} else "auto"
        )
        call_language = str(data.get("pet_call_input_language") or "zh").strip().lower()
        data["pet_call_input_language"] = "ja" if call_language == "ja" else "zh"
        data["pet_call_silence_ms"] = max(350, min(1800, int(data.get("pet_call_silence_ms", 650))))
        data["pet_call_voice_threshold"] = max(0.004, min(0.12, float(data.get("pet_call_voice_threshold", 0.018))))
        data["pet_call_min_speech_ms"] = max(150, min(1500, int(data.get("pet_call_min_speech_ms", 280))))
        data["pet_call_max_turn_seconds"] = max(5, min(45, int(data.get("pet_call_max_turn_seconds", 18))))
        data["bubble_seconds"] = max(3, min(30, int(data.get("bubble_seconds", 9))))
        data["pet_size_percent"] = max(80, min(240, int(data.get("pet_size_percent", 150))))
        # 公开版只保留 Live2D 桌宠形象：历史数据里的静态立绘模式统一迁移。
        pet_renderer = str(data.get("pet_renderer") or "live2d").strip().lower()
        data["pet_renderer"] = "live2d" if pet_renderer in {"classic", "live2d"} else "live2d"
        live2d_model_id = str(data.get("live2d_model_id") or "hiyori").strip().lower()
        available_model_ids = self._dep__live2d_model_ids()
        data["live2d_model_id"] = live2d_model_id if live2d_model_id in available_model_ids else "hiyori"
        data["live2d_scale"] = max(0.65, min(1.55, float(data.get("live2d_scale", 1.0))))
        data["live2d_vertical_offset"] = max(-0.35, min(0.35, float(data.get("live2d_vertical_offset", 0.0))))
        data["live2d_follow_cursor"] = bool(data.get("live2d_follow_cursor", True))
        data["live2d_idle_motion"] = bool(data.get("live2d_idle_motion", True))
        data["live2d_click_motion"] = bool(data.get("live2d_click_motion", True))
        data["live2d_smart_passthrough"] = bool(data.get("live2d_smart_passthrough", True))
        data["live2d_click_through_locked"] = bool(data.get("live2d_click_through_locked", False))
        data["live2d_speech_bubble_enabled"] = bool(data.get("live2d_speech_bubble_enabled", True))
        data["live2d_keep_visible"] = bool(data.get("live2d_keep_visible", False))
        data["live2d_always_on_top"] = bool(data.get("live2d_always_on_top", True))
        data["live2d_disable_gpu"] = bool(data.get("live2d_disable_gpu", False))
        data["live2d_motion_slots"] = self._normalize_live2d_motion_slots(data.get("live2d_motion_slots"))
        data["live2d_expression_slots"] = self._normalize_live2d_expression_slots(data.get("live2d_expression_slots"))
        data["position_x"] = max(-10000, min(10000, int(data.get("position_x", 80))))
        data["position_y"] = max(-10000, min(10000, int(data.get("position_y", 420))))
        return data

    def save_config(self, changes: dict[str, Any]) -> dict[str, Any]:
        data = self.load_config()
        for key in self._dep_DEFAULT_CONFIG():
            if key in changes:
                data[key] = changes[key]
        # 额外业务字段（如 live2d_model_schedule）不在默认配置键表，也必须写入，
        # 否则"自动更换/时间/模式"等设置保存后会被静默丢弃、回默认值
        for key in changes:
            if key not in self._dep_DEFAULT_CONFIG():
                data[key] = changes[key]
        normalized = self.load_normalized_config(data)
        known_keys = set(self._dep_DEFAULT_CONFIG())
        # 保留默认配置键 + 配置中已存在的额外键（如 live2d_model_schedule），
        # 避免新增业务字段在保存时被过滤器丢弃导致"设置保存不了、回默认值"
        extra_keys = {key for key in data if key not in known_keys}
        data = {
            key: value
            for key, value in normalized.items()
            if key in known_keys or key in extra_keys
        }
        self._dep_settings().companion_dir.mkdir(parents=True, exist_ok=True)
        temporary = self._dep_settings().companion_config_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(self._dep_settings().companion_config_path)
        from .. import pet_event_service

        pet_event_service.publish("settings_changed", data)
        return data

    def load_normalized_config(self, data: dict[str, Any]) -> dict[str, Any]:
        normalized = dict(self._dep_DEFAULT_CONFIG())
        normalized.update(self._migrate_config(data))
        normalized["voice_enabled"] = bool(normalized.get("voice_enabled", True))
        normalized["voice_volume"] = max(0, min(100, int(normalized.get("voice_volume", 85))))
        normalized["voice_streaming_enabled"] = bool(normalized.get("voice_streaming_enabled", True))
        pet_speech_language = str(normalized.get("pet_speech_language") or "zh").strip().lower()
        normalized["pet_speech_language"] = pet_speech_language if pet_speech_language in {"zh", "ja"} else "zh"
        normalized["speak_screen_observations"] = bool(normalized.get("speak_screen_observations", True))
        normalized["speak_game_observations"] = bool(normalized.get("speak_game_observations", True))
        normalized["screen_ai_enabled"] = bool(normalized.get("screen_ai_enabled", True))
        normalized["screen_audio_enabled"] = bool(normalized.get("screen_audio_enabled", True))
        screen_audio_model = str(normalized.get("screen_audio_model") or "base").strip().lower()
        normalized["screen_audio_model"] = screen_audio_model if screen_audio_model in {"tiny", "base", "small"} else "base"
        screen_audio_language = str(normalized.get("screen_audio_language") or "auto").strip().lower()
        normalized["screen_audio_language"] = screen_audio_language if screen_audio_language in {"auto", "zh", "ja", "en"} else "auto"
        normalized["screen_audio_chunk_seconds"] = max(4, min(15, int(normalized.get("screen_audio_chunk_seconds", 5))))
        screen_vision_route = str(normalized.get("screen_vision_route") or "local").strip().lower()
        normalized["screen_vision_route"] = screen_vision_route if screen_vision_route in {"local", "cloud"} else "local"
        normalized["screen_vision_model_id"] = (
            str(normalized.get("screen_vision_model_id") or "auto-fast").strip()[:200] or "auto-fast"
        )
        normalized["screen_direct_voice_enabled"] = bool(normalized.get("screen_direct_voice_enabled", True))
        normalized["screen_change_threshold"] = max(1.0, min(50.0, float(normalized.get("screen_change_threshold", 4.0))))
        normalized["screen_analysis_interval_seconds"] = max(5, min(600, int(normalized.get("screen_analysis_interval_seconds", 5))))
        normalized["screen_request_timeout_seconds"] = max(5, min(60, int(normalized.get("screen_request_timeout_seconds", 25))))
        normalized["screen_voice_cooldown_seconds"] = max(5, min(600, int(normalized.get("screen_voice_cooldown_seconds", 5))))
        normalized["screen_minimum_importance"] = max(0.1, min(1.0, float(normalized.get("screen_minimum_importance", 0.62))))
        normalized["screen_daily_cost_limit_yuan"] = max(0.1, min(1000.0, float(normalized.get("screen_daily_cost_limit_yuan", 5.0))))
        call_asr_engine = str(normalized.get("pet_call_asr_engine") or "auto").strip().lower()
        normalized["pet_call_asr_engine"] = (
            call_asr_engine if call_asr_engine in {"auto", "whisper", "sensevoice", "paraformer"} else "auto"
        )
        call_language = str(normalized.get("pet_call_input_language") or "zh").strip().lower()
        normalized["pet_call_input_language"] = "ja" if call_language == "ja" else "zh"
        normalized["pet_call_silence_ms"] = max(350, min(1800, int(normalized.get("pet_call_silence_ms", 650))))
        normalized["pet_call_voice_threshold"] = max(0.004, min(0.12, float(normalized.get("pet_call_voice_threshold", 0.018))))
        normalized["pet_call_min_speech_ms"] = max(150, min(1500, int(normalized.get("pet_call_min_speech_ms", 280))))
        normalized["pet_call_max_turn_seconds"] = max(5, min(45, int(normalized.get("pet_call_max_turn_seconds", 18))))
        normalized["bubble_seconds"] = max(3, min(30, int(normalized.get("bubble_seconds", 9))))
        normalized["pet_size_percent"] = max(80, min(240, int(normalized.get("pet_size_percent", 150))))
        pet_renderer = str(normalized.get("pet_renderer") or "live2d").strip().lower()
        normalized["pet_renderer"] = "live2d" if pet_renderer in {"classic", "live2d"} else "live2d"
        live2d_model_id = str(normalized.get("live2d_model_id") or "hiyori").strip().lower()
        available_model_ids = self._dep__live2d_model_ids()
        normalized["live2d_model_id"] = live2d_model_id if live2d_model_id in available_model_ids else "hiyori"
        normalized["live2d_scale"] = max(0.65, min(1.55, float(normalized.get("live2d_scale", 1.0))))
        normalized["live2d_vertical_offset"] = max(-0.35, min(0.35, float(normalized.get("live2d_vertical_offset", 0.0))))
        normalized["live2d_follow_cursor"] = bool(normalized.get("live2d_follow_cursor", True))
        normalized["live2d_idle_motion"] = bool(normalized.get("live2d_idle_motion", True))
        normalized["live2d_click_motion"] = bool(normalized.get("live2d_click_motion", True))
        normalized["live2d_smart_passthrough"] = bool(normalized.get("live2d_smart_passthrough", True))
        normalized["live2d_click_through_locked"] = bool(normalized.get("live2d_click_through_locked", False))
        normalized["live2d_speech_bubble_enabled"] = bool(normalized.get("live2d_speech_bubble_enabled", True))
        normalized["live2d_keep_visible"] = bool(normalized.get("live2d_keep_visible", False))
        normalized["live2d_always_on_top"] = bool(normalized.get("live2d_always_on_top", True))
        normalized["live2d_disable_gpu"] = bool(normalized.get("live2d_disable_gpu", False))
        normalized["live2d_motion_slots"] = self._normalize_live2d_motion_slots(normalized.get("live2d_motion_slots"))
        normalized["live2d_expression_slots"] = self._normalize_live2d_expression_slots(normalized.get("live2d_expression_slots"))
        normalized["position_x"] = max(-10000, min(10000, int(normalized.get("position_x", 80))))
        normalized["position_y"] = max(-10000, min(10000, int(normalized.get("position_y", 420))))
        return normalized

    def save_pet_position(self, x: int, y: int) -> dict[str, Any]:
        return self.save_config({"position_x": x, "position_y": y})

    def save_pet_size(self, percent: int) -> dict[str, Any]:
        return self.save_config({"pet_size_percent": percent})
